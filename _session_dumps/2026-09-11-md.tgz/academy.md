# Academy — 2026-09-11

- **Date:** 2026-09-11 (Bogotá)
- **Agent:** Academy (`b65940e2-462d-44fd-92d8-2a4793a6c9d0`)
- **Who was in it:** Gideon Blaauw; Academy desk

## Decisions
- Deploy Marlene Datathon HTML to production URL `https://marlene-datathon-cth.vercel.app`.
- Whiteboard photo summarized as CTH × CEE / REIN Digitization + Datathon Lab flow (n8n → Baserow → Metabase).
- Live Vercel briefly shipped text-first then visual landing with baked-in images after asset 404s; 16-slide clicker vs visual landing left as follow-up choice.

## Action items
- Gideon: confirm whether production URL should be the original 16-slide clicker on top of restored assets, or keep the visual landing (“Del diagnóstico al tablero en vivo”).
- Optional: put whiteboard summary/wire on Drive Doc or Notion (offered, not requested further in extract).

## Links / files
- Live: https://marlene-datathon-cth.vercel.app
- Wire PNG: `/workspace/harness/reports/2026-09-11-cth-cee-rein-whiteboard-wire.png`
- Deck assets: `/workspace/harness/reports/marlene-datathon-deck/assets/`
- Self-contained HTML attachment: `2026-09-11-marlene-datathon-deck-with-images.html`
- Whiteboard source: WhatsApp Image 2026-09-09 at 17.51.56.jpeg

## Still open
- Clicker HTML vs visual landing on the same Vercel URL.
- Board pendientes: anchor Lab under REIN with CEE; standardize n8n→Baserow→Metabase; confirm Academy calendar dates; KPIs; APC/CAF/ESRI roles.

## Notes
Morning: Gideon asked to put the HTML deck on the Marlene Vercel link; deploy went through several stub/probe/empty (11-byte) failures before visuals loaded (hard-refresh). Same session: whiteboard photo → Spanish meeting summary + wire diagram for CTH × CEE / REIN (Academy/Datathon track A vs CEE research track B; GEN SGE / Semana Global timing noted).
