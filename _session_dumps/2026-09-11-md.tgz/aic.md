# AIC — 2026-09-11

- **Date:** 2026-09-11 (Bogotá)
- **Agent:** AIC (`558f5c27-6af0-41e3-82ec-c7fc3ba12069`)
- **Who was in it:** Gideon Blaauw; AIC desk; Hands (`bc-6a7a4280-44a6-4d90-9f4d-a82a990c82f4`, `bc-2435701e-2be6-4538-85ea-a1a21e63f651`); Images desk (Corridor stills)

## Decisions
- Host deck audience = LatAm corporate buyers; drop AS/COA; sector lock = Finance; Latin Forum deal = promo code → regs → round table (speed dating/cocktail optional).
- New closer slogan: “You keep the conference. We fill the Latin Forum with LatAm buyers.”; +30% type size.
- 10 LinkedIn drafts highlight Startup Showdown contestants for LatAm finance pros; every post ends with register CTA; HITL — nothing posted.
- Stills palette navy/blue/amber/white; no CTH lime/logo, no named likenesses, no bank/startup/card logos.

## Action items
- Gideon: review Notion pack + stills; say a number if one post should go live (HITL post).
- OpenRouter was 402 then topped up; pack regenerated — confirm Gideon is happy with frames before any post.

## Links / files
- Host deck Vercel: https://aic-ai-conference-host.vercel.app
- Hands host deck: `bc-6a7a4280-44a6-4d90-9f4d-a82a990c82f4`
- Notion 10 drafts + stills: https://app.notion.com/p/3d8dfee50be98164b3f5c4a351384fe1
- PR #3: https://github.com/gideonblaauw-creator/runupholdings-matters/pull/3
- Hands LI drafts: `bc-2435701e-2be6-4538-85ea-a1a21e63f651`
- Stills: `/workspace/aic/li-stills-showdown/01.png` … `10.png` (openai/gpt-image-1)
- Register CTA: https://aiconference.com/#tickets
- Roster source: https://aiconference.com/startups/

## Still open
- No LinkedIn posts live (HITL).
- Which of the 10 (if any) to publish first.

## Notes
Morning pass fixed the Frank host HTML deck and published it to Vercel. Afternoon: 10 Spanish Startup Showdown LinkedIn drafts landed on Notion/PR with register CTAs; Corridor stills briefly blocked on OpenRouter 402 until Gideon topped up, then all 10 PNGs were generated and embedded on Notion. Assets and copy only — nothing posted.
