# CCF — 2026-09-11

- **Date:** 2026-09-11 (Bogotá)
- **Agent:** CCF (`254409c1-bf72-449b-883c-23d22f1314bf`)
- **Who was in it:** Gideon Blaauw; CCF desk; Hands (`bc-da80facc-ab51-4183-b97c-357963844380`); Pratap (follow-up target, not messaged)

## Decisions
- Pilot stays pending Teclogi; other Impact Assessment deliverables to Pratap are LoI → MoU terms → business plan.
- Party A for this LoI = Fundación Cleantech Hub (not CLEANTECHHUB INTERNATIONAL S.L.).
- Scope widened: Climate Tech Impact + Mosambi (CTH client-facing) + S2C2/CCF products; territory Colombia + LatAm ex Brazil.
- LoI is DRAFT / HITL — nothing sent to Pratap.

## Action items
- Gideon: fill [PENDIENTE] on LoI (NIT, CCF legal name, exclusivity/confidentiality days, governing law Colombia/Bogotá vs Spain/Barcelona, term).
- Gideon: send WhatsApp accompanying text + Doc link to Pratap when ready (HITL; desk drafted paste-ready copy only).
- Still due later: business plan + formal MoU by 20 Sep; Medellín Climate Week launch package 27 Sep–10 Oct.

## Links / files
- LoI Doc (HTML native, current): https://docs.google.com/document/d/1sOVHu94q2JibPw8qINNNBHZpdEGGZPT9gLAUOC67d-s/edit
- Folder: https://drive.google.com/drive/folders/17XrHNrSM26RiPkTAcKGqeTiHcaSHZWUV
- Archive: `/opt/claude-files/Projects/CCF/2026-09-11-loi-ccf-cleantechhub/`
- Hands: `bc-da80facc-ab51-4183-b97c-357963844380`
- Source sheet: `THOUGHTS - S2C2 partnership - 18 Aug 26 (1).xlsx`

## Still open
- LoI unsent to Pratap; [PENDIENTE] fields above.
- MoU framework blanks (objectives/resources, exclusivity, IP foreground wording, pie-split, governance).
- Business plan numbers waiting PRCE pricing floor / Pratap input.
- Teclogi pilot separate / pending.

## Notes
Gideon attached the S2C2 partnership xlsx and prioritized Pratap follow-ups on Impact Assessment. Desk drafted an India/Colombia-compatible LoI structure, then Hands wrote and repeatedly reformatted a Google Doc after markdown-dump failures; final Doc is native HTML with prior dumps marked superseded. Paste-ready WhatsApp copy for Pratap was prepared; HITL send still held.
