# CEE Externado — 2026-09-11

- **Date:** 2026-09-11 (Bogotá)
- **Agent:** CEE Externado (`858f55c1-879d-4892-a59b-22de8d0dde4c`)
- **Who was in it:** Gideon, Orchestrator (t1188u / t1199u), CEE Externado desk, Hands on VPS (`bc-e6beee9f-75ae-4859-8fcb-313d1a5b864c`)

## Decisions
- Stand up Externado workstream: inventory + aclaratoria + partnership triangle (HITL DRAFT/NO ENVIAR).
- SoT for marco: Convenio Fundación Cleantech HUB × Universidad Externado, instrument 3 Jul 2024, 5 years.
- Triangle working assumption kept: vertices CTH × CEE Externado × Observatorio; four inside = Datathon, Climate Data Week, Data Lab, Research; rails Programs + Finance.
- Aclaratoria must mirror signed 5y convenio legal + visual format (not a data dump); SGND PDF wins over brand skills where they conflict.
- First Hands launch failed (missing repo); relaunched on parking repo `cth-matters`.

## Action items
- HITL before any Externado share/sign on inventory, aclaratoria, or triangle.
- Fill remaining [PENDIENTE]s: última-firma clock, CCE 2025 MoU standalone PDF, REIN derivado, Comité Coordinador names, CEE validation of “Observatorio” nomenclature (not in 2024 marco), sede/IP/cuantías, signature date.
- Residual Docs trailing header-only page after firmas on aclaratoria.

## Links / files
- Hands: https://cursor.com/agents/bc-e6beee9f-75ae-4859-8fcb-313d1a5b864c
- Inventory Doc: https://docs.google.com/document/d/10CgtHHn6W2UXQxLTJtY8e-hK1YFUj10Qfkc7F4w05R0/edit
- Pack folder: https://drive.google.com/drive/folders/17Cl7BNfiLpi06N5kN4rGoEYbrbHdbtXv
- Fuentes: https://drive.google.com/drive/folders/1drJFpgyEWt1sCJnoCbqk85FLapiSQmYJ
- 5y SGND PDF: https://drive.google.com/file/d/1CooUhwZzijLNcUGnLYZY8F1hT7UxP8g4/view
- Aclaratoria (rewritten + restyled in place): https://docs.google.com/document/d/1D7G4xBbGUa4AFnMuRiIVPVhZcPHKnjiEV8v_9C2Jo7c/edit
- Deprecated dump rollback: https://docs.google.com/document/d/1gg2Xd2vm4djghxJOIByyPWSJMeVq_KRnsVnUJd-CRAM/edit
- Triangle PNG: https://drive.google.com/file/d/1NecrkCDBXAiBcGqFqmx_9wiOrXEqswGI/view
- Triangle Doc: https://docs.google.com/document/d/1mOi5yHZ8RUzStor5McitbDdTZtIiNyd-ElN1VwcSNmk/edit

## Still open
- Aclaratoria substance [PENDIENTE]s and trailing blank header page.
- No send/sign to Externado.

## Notes
Priority t1188u delivered inventory, Spanish aclaratoria from the 2024 marco, and triangle pack via Hands `bc-e6beee9f`; Gideon rejected dump-style aclaratoria, then Orchestrator t1199u required a visual twin of the signed SGND (Tahoma 11, dual logos, bold clause titles, 1″ margins, yellow DRAFT banner only). Restyle READY at 13:47; everything remains HITL DRAFT/NO ENVIAR.
