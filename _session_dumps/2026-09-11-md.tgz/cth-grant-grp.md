# CTH Grant · GRP — 2026-09-11

- **Date:** 2026-09-11 (Bogotá)
- **Agent:** CTH Grant · GRP (`c8de93b6-f550-49c6-9d74-0d38558d9b4d`)
- **Who was in it:** Gideon, GRP desk; Juan Fernando Lucio (PASO) comments quoted; Mercy referenced in Juan’s note

## Decisions
- Juan’s note read as yellow flag, not a walk: reopen scope/share before concluding PASO can’t continue.
- USD 10k PASO line is the **25k floor scenario**, not a rewrite of the 13 Aug Mercy deal (PASO 20k at 50k).
- If 25k doesn’t work for PASO field ops, consortium path = apply only for **USD 50k / PASO 20k**.
- Agree with Juan: field operating model first; studies/learning as byproduct, not center.
- Don’t negotiate by email; don’t re-cut PASO without him in the room; don’t write GRP first.

## Action items
- Call this week with Mercy + Juan (same day if possible); own the 10k mix-up on the call.
- HITL: one-pager not shared with Mercy/Juan yet; Juan reply draft offered but not confirmed sent.
- Optional: draft Juan reply pointing at one-pager + call ask.

## Links / files
- Budget sheet: https://docs.google.com/spreadsheets/d/1ih4uoxoZ03CzIUnEXN1z0csM7wP66FFpv8FDkKoLyXg/edit
- One-pager (25k vs 50k, campo primero): https://docs.google.com/document/d/1hV1qp9KHMx7gEK2Q86yhlW7cqGd15HMclTPpKwhbA8k/edit

## Still open
- Meeting with Juan/Mercy; PASO stay-on-board outcome.
- Whether to send Juan the one-pager / reply draft (HITL).
- Sep 18 deadline pressure noted in Juan’s note.

## Notes
Gideon pasted JF Lucio’s Spanish note (budget ~10k + ops vs studies). Desk traced 10k to the 25k floor column in the 25 Aug GRP budget sheet (line 7.1 PASO: 20k @ 50k / 10k @ 25k) and wrote an unsent one-pager explaining GRP requires both budgets, favoring 50k/field-first. No email sent from this desk.
