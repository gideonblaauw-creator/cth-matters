# CTH Grants — 2026-09-11

- **Date:** 2026-09-11 (Bogotá)
- **Agent:** CTH Grants (`9360f6b2-d0ed-48d7-b36e-7a920adb62f5`)
- **Who was in it:** Gideon (via Orchestrator priority t1182u), CTH Grants desk, Hands (`bc-9fbe0876-649b-4ce7-ae0a-60a833236ff8`)

## Decisions
- Claimed grant draft slot #2 (beside GRP, live to 18 Sep) for Interledger Local Impact Mini-Grant × Datathon; TEEEM stays parked.
- Applicant default Fundación CleantechHUB; commercial S.L. vs Foundation still [PENDIENTE] HITL.
- Angle locked as workshop + open-payments sprint for climate MSMEs (honest FIT GAP — no ILP builds claimed).
- DRAFT / NO ENVIAR — nothing submitted to portal.

## Action items
- HITL Gideon before any Interledger portal submit (deadline 11 Nov 2026 23:59 ET, rolling).
- Resolve Doc HITL: entity, exact $, Cámara coupling/LOI, sprint date, US payout rails.
- Later (not this ticket): add Climathons organizing experience to GIZ facilitation reseña.

## Links / files
- Portal: https://submit.interledger.org/submit/356649/2026-interledger-local-impact-mini-grant
- Program: https://interledger.org/grant/local-impact
- Hands: https://cursor.com/agents/bc-9fbe0876-649b-4ce7-ae0a-60a833236ff8
- Owner-only folder: https://drive.google.com/drive/folders/1ny2s64yiV8sESpaaOjDvgFMNncMocnMn
- Main Doc: https://docs.google.com/document/d/1LMM4l6hR17nP2LtlU2_t7fEUgyyjf0gSeXTJLrGcFIY/edit
- Budget Sheet: https://docs.google.com/spreadsheets/d/146oqUjDep_LZGiGnZPuEB_U23XVYHhgQrbFX5znjTJE/edit
- Datathon sources: Chamber design Doc `1eD2kVQY7NpzRX-4o71qLUm5qhk5KdFiM74v9RnMZZvs`; DigComp Doc `1JeUgNDV40XwAmv6K_ZZTEn1V-tVMcR3QhYXgp_xbtjM`; wire PNG `1ZMaHyHglSoFU-neMC2ZzFXJggFcsxngf`; research Doc `1ZntU2rwyHwfZjLnrmeeCcKtDqgBRWSJhMkqWROwuErA`

## Still open
- Exact budget line items [PENDIENTE] — working ask $2,500 skeleton only.
- Entity (Foundation vs S.L.), Cámara LOI, sprint date, payout rails — HITL.
- Portal submit not done; Verify PASS with flags only.

## Notes
Morning ticket built a Lane B Interledger × Datathon draft pack under Proposals/2026 (tree 00/01/03/04/06). Grants Verify PASS with flags: honest FIT GAP, personnel ≤40% noted, owner-only folder/Doc, no share, no portal submit. Some markdown-ish bold artifacts in Doc extract accepted for HITL. Slot #2 beside GRP; TEEEM parked.
