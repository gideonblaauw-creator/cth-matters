# FabFloow — 2026-09-11

- **Date:** 2026-09-11 (Bogotá)
- **Agent:** FabFloow (`50293a49-c0a6-4e3e-aeec-439354f6f2e5`)
- **Who was in it:** Gideon (~13:50–14:43 COT).

## Decisions
- Review https://fabfloow-site.vercel.app → 10 improvements; Gideon GO on all 10 (widget).
- Hands rebuild **fabfloow-site only** — partner deck and LexiScan app untouched.
- Team: Gideon, Angélica Díaz, Gio (Giovanny Trujillo), Jonathan Cipagauta — LinkedIn cards; photos: CTH About for Gideon/Angélica/Jonathan, LinkedIn for Gio. Real photos only (no AI drawings).
- LexiScan demo link in header + featured card → https://fabfloow-lexiscan.vercel.app

## Action items
- **Gideon** — hard-refresh / eyeball live site; further copy or contact-flow tweaks if needed (HITL).

## Links / files
- Live site: https://fabfloow-site.vercel.app
- LexiScan demo: https://fabfloow-lexiscan.vercel.app
- Hands: `bc-1bb7ff33-cf3a-4268-98b3-c9ba4c5dfcab`
- Team LinkedIns (as given): gideon-blaauw, angelicadiazb, giovannytrujilloadminpublico, jonathan-mauricio-cipagauta-lópez
- Photo source: https://www.cleantechhub.net/about/

## Still open
- None critical in-chat; site called live after photo + Demo nav pass.

## Notes
- Ten fixes shipped: Abrir demo LexiScan CTAs, Spanish H1, hero WebP, brick carpeta still removed (cream), Solicitar demo → CTH mailto (no invented inbox), favicon/OG, LexiScan featured + Próximo strip, Spanish team blurbs + LinkedIns, mobile wordmark nowrap. Follow-ups added Demo in nav and Equipo headshots. HITL before Hands; no invent prices/CTH lime. Nothing posted beyond Vercel deploy of the site.
