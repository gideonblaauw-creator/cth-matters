# Monday · Teclogi — 2026-09-11

- **Date:** 2026-09-11 (Bogotá)
- **Agent:** Monday · Teclogi (`2592cf74-3a18-4284-87da-e270a6a8fc8e`)
- **Who was in it:** Gideon (approved weekday CRM standup), Monday · Teclogi desk

## Decisions
- Created durable routine **Teclogi Monday CRM standup** (`teclogi-monday-crm-standup`).
- Schedule: `0 8 * * 1-5` (8:00am America/Bogotá, weekdays).
- Digest to Gideon only; never send LinkedIn/email/WhatsApp; never print tokens.
- Auth: `MONDAY_TECLGI_API_TOKEN` if set, else `MONDAY_ADMIN_API_TOKEN`.

## Action items
- First real run: Mon 14 Sep 8:00am Bogotá (optional one-shot dry-run if Gideon asks).
- If auth fails twice across runs: pause routine and tell Gideon.

## Links / files
- Board: https://cleantechhub-foundation.monday.com/boards/18425305222 (Teclogi — Series A Fundraise, id 18425305222)
- Repo context: `gideonblaauw-creator/teclogi-monday`

## Still open
- First weekday digest not yet run (next Mon 14 Sep).
- Dry-run offered; Gideon response not in this session.

## Notes
Gideon approved the weekday CRM standup. Desk saved the routine and confirmed schedule + first run. Each run: Snapshot (counts by Status/Priority), Hygiene (safe empty-field / bad-Priority fixes only), ACTION ITEMS (stale Active ≥7d top 15, pending reply top 10, pending our move top 10, new/changed), Blockers — keep under ~40 lines; always send at least Snapshot + Action items.
