# REIN Hubs — 2026-09-11

- **Date:** 2026-09-11 (Bogotá)
- **Agent:** REIN Hubs (`fd48890b-0127-49e6-a6c4-1adbf52337ca`)
- **Who was in it:** Gideon; REIN Hubs desk; draft addressed to Stephen (stephen@pvblic.org)

## Decisions
- Draft (unsent) email to Stephen on Externado × Datathon / Datalab fit for REIN, plus Climate Data Week path (Bangalore CDW as example).
- Second pass: no Marlene deck / Vercel link in the body; keep five-step substance from the deck.
- Architecture frame in draft: Earth Observatory legs Academy / Datalab / Research / Finance; Datathon as Datalab product.
- HITL — nothing in Gmail; still unsent.

## Action items
- HITL: send vs further tweak (shorter / more FOSD-capital / Spanish / drop into Gmail drafts) still open.
- Dates, cohort size, certificate naming left open pending Stephen’s REIN-fit read.

## Links / files
- Attached context (user): `2026-09-09-marlene-datathon-deck v3.html` + `image.png` (not linked in final rewrite).
- Site referenced then removed from rewrite: https://marlene-datathon-cth.vercel.app/
- Example convening cited: https://bangalore.climatedataweek.org/

## Still open
- Stephen email unsent; optional fold into next CCE Hubs Thursday / short call.
- Packaging lock with Externado waits on Stephen read.

## Notes
Gideon asked for a Stephen note tying Externado Datathon (part of Datalab under Earth Observatory) to REIN and Climate Data Week; desk produced an unsent English draft, then rewrote without Marlene/deck URLs after Gideon’s redo. Still HITL unsent; offered Gmail-drafts drop or tone tweaks.
