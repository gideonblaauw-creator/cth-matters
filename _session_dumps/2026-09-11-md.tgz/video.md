# Video — 2026-09-11

- **Date:** 2026-09-11 (Bogotá)
- **Agent:** Video (`14123e40-6b83-4abd-8deb-80ca2f622ec5`)
- **Who was in it:** Gideon Blaauw; Video desk; Orchestrator (t1192u); Hands (`bc-98a84c8b-7b32-40d3-b44d-c264343b446a`)

## Decisions
- GO on Final Nacional ClimateLaunchpad 2026 sizzle from CTH YouTube VOD `EocBYcPRryw`; DRAFT / NO POST.
- Music = source ambient only; stock music [PENDIENTE].
- On-screen winner lock: `Curuba Tech` (two words); 3º TERRA IO · 2º Bio.Analytics · 1º Curuba Tech.
- Gideon rejected linear ~60s highlight dump; rebuild as high-speed trailer (~40–50s: slam / flash cuts / winner cascade / outro).

## Action items
- Gideon HITL: review trailer MP4s before any social post (no Buffer/LI publish).
- Optional: compare Hands ~41s Drive trailer vs local ~44s alternate in chat/`/workspace/youtube-EocBYcPRryw/trailer/`.

## Links / files
- Source: https://www.youtube.com/watch?v=EocBYcPRryw
- Drive folder: https://drive.google.com/drive/folders/1n_NGl9fUpElEHkKi99OhBh_UdUjaLTEW
- Cut-list Doc: https://docs.google.com/document/d/13-cNKaV8Ov_vfcMl0KSeBt9lcAuC5iGHiNpVRO-LJQ0/edit
- Trailer 16:9: https://drive.google.com/file/d/1pjl8_UxfOa2g0KV6eocGMjBKfeiyN1Ey/view
- Trailer 9:16: https://drive.google.com/file/d/1d5s2XmKfigvB1AMVOJ0aFXBiqR_igw-K/view
- Hands: `bc-98a84c8b-7b32-40d3-b44d-c264343b446a`
- VPS: `/opt/claude-files/Projects/CleantechHUB/2026-09-11-clp-nacional-sizzle-*.mp4`

## Still open
- Stock music still [PENDIENTE] if needed.
- HITL post/publish of trailer.
- Earlier linear v1/v1.5 Drive URLs superseded by trailer pack.

## Notes
Priority t1192u: cut list locked, Hands assembled on VPS, then Gideon rejected plain vanilla encodes. After a failed linear “Curuba Tech” fix still at ~60s, Video stood Hands down for local assemble while a true ~41s slam/flash trailer also landed from Hands on Drive (plus a ~44s local alternate). Spanish supers, source audio only, DRAFT / NO POST.
